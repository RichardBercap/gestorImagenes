<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/test', 'AjaxController@test');
Route::post('/test', 'AjaxController@test');

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/admin', 'IndexController@index');
Route::resource("album","AlbumController");
Route::resource("album/fotos","FotoController");
Route::get('/admin/album/{id}','IndexController@foto');
Route::get('/eliminar/{id}','FotoController@destroy');


//creando redireccion de error 404
/*App::missing(function($exception){
  return Response::view("error.error",array(),404);
});*/
