<?php $__env->startSection('content'); ?>


<?php ($i = 1); ?>

    <?php if(count($fotos) == 0): ?>

            <h1 class="fotos-no">
              No tienes Fotos en esté Albúm <br>
              <b>
                <span class="glyphicon glyphicon-camera"></span>
              </b>


             </h1>

    <?php endif; ?>

    <?php if(count($fotos) > 0): ?>

      <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

          <div class="col-xs-3 foto">
            <h3><?php echo $foto->nombre; ?></h3>
              <img src="<?php echo e(asset('Fotos')); ?>/<?php echo $foto->ruta; ?>" alt="" class="img-responsive imagen" style="height: 20rem;">
              <a href="<?php echo e(url('eliminar/')); ?>/<?php echo $foto->id; ?>" class="btn btn-danger btn-lg col-xs-12">Eminiar</a>
          </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <?php endif; ?>
<div class="row">
  <button type="button" class="btn btn-primary btn-lg col-xs-12" name="button"  data-toggle="modal" data-target="#myModal">
    A g r e g a r    F o t o
  </button>
</div>





<!--*********** Modal **************-->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
        &times;
        </button>
        <h4 class="modal-title" id="myModalLabel">
        Llena el formulario
        </h4>


      </div>

      <div class="modal-body">
        <div class="form">
             <?php echo e(Form::open(['route' => 'fotos.store', 'method' => 'post','files' => true, 'enctype' => 'multipart/form-data'])); ?>

                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                 <div class="form-group">
                     <?php echo e(Form::label("Nombre:")); ?>

                     <?php echo e(Form::text("nombre",null, array_merge(['class' => 'form-control', 'placeholder'=>'Ingresa el nombre']))); ?>

                 </div>
                 <div class="form-group">
                    <?php echo e(Form::label("Ruta de la foto:")); ?>

                    <?php echo e(Form::file("ruta",null, array_merge(['class' => 'form-control']))); ?>

                 </div>
                 <div class="form-group">
                    <?php echo e(Form::hidden("id_album",$id_album, array_merge(['class' => 'form-control']))); ?>

                 </div>
                 <?php echo e(Form::submit("Subir", ['class' => 'btn btn-primary col-xs-12'])); ?>

             <?php echo Form::close(); ?>

         </div>
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger col-xs-12" data-dismiss="modal"> Close</button>

      </div>
  </div><!-- /.modal-content -->
  </div><!-- /.modal -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>