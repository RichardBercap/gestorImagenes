<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  </head>
  <body class="fondo-img">
    <header class="cabecera col-xs-12">
        <h1>Gestor Imagenes en Laravel 5</h1>

    </header>
    <h2 class="text-center titulo-2">Bienvenido a gestor de imagenes</h2>
    <hr>
    <p class="text-center">Para empezar debes crear una cuenta en GestorImagenes</p>
    <div class="row text-center">
        <a href="/register"  class="btn btn-info col-xs-4 text-center col-md-offset-4">Crear cuenta</a>
    </div>

    <div class="col-xs-12">
      <div class="btn-group col-md-offset-3">
        <a href="#" class="btn btn-success">Que puedes hacer</a>
        <a href="#" class="btn btn-info">Confidencialidad de tus fotos</a>
        <a href="#" class="btn btn-warning">Estado de Fotos</a>
        <a href="#" class="btn btn-danger" id="btnajax">Prueba Ajax</a>
      </div>
  

    </div>

  </body>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
  <script type="text/javascript">
    $("#btnajax").on("click", function(){
      /*$.get('/test', function(){
        console.log('response');
      });*/
;
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "/test",
        type: "POST"
      });
      $.ajax({
          success: function( msg ) {
                  console.log(msg);
            }
          });
    });
  </script>
</html>
