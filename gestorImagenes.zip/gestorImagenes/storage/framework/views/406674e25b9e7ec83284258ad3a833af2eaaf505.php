<?php $__env->startSection('content'); ?>

<div class="row col-xs-100">
  <h1 class="text-center"><?php echo e($user->name); ?></h1>
</div>
    <p>You are an Admin</p>
    <hr>
    <blockquote>
      <p>Con este sitio guardaras tus fotos de forma segura</p>
    </blockquote>
    <div class="panel panel-default">
      <div class="panel-header">
        <h3>Tus albunes</h3>
      </div>
        <div class="panel-body">
          <?php if(count($albums) == 0): ?>
              <div class="alert alert-danger">
                  <h4>No tienes albunes crados</h4>
              </div>
          <?php endif; ?>
          <?php if(count($albums) > 0): ?>
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <a href="/admin/album/<?php echo $album->id; ?>">
                <div class="col-xs-3 album id='<?php echo $album->id; ?>'">
                  <h3><?php echo $album->nombre; ?></h3>
                  <p class="text-justify">
                    <?php echo $album->descripcion; ?>

                  </p>
                </div>
              </a>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php endif; ?>

        </div>
      </div>
      <br>
      <div class="row">
          <button type="button" name="button" class="btn col-xs-4 btn-success" data-toggle="modal" data-target="#myModal">
            <span class="glyphicon glyphicon-plus"></span>
            <p>Crear Nuevo Album</p>
          </button><br><br><br>
          <div class="row">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
          </div>

          <!-- Modal -->

          <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                  &times;
                  </button>
                  <h4 class="modal-title" id="myModalLabel">
                  Llena el formulario
                  </h4>


                </div>

                <div class="modal-body">
                  <div class="form">
                       <?php echo e(Form::open(['route' => 'album.store', 'method' => 'post','files' => true])); ?>

                           <div class="form-group">
                               <?php echo e(Form::label("Nombre del albúm:")); ?>

                               <?php echo e(Form::text("nombre",null, array_merge(['class' => 'form-control', 'placeholder'=>'Ingresa el nombre']))); ?>

                           </div>
                           <div class="form-group">
                              <?php echo e(Form::label("Descripción:")); ?>

                              <?php echo e(Form::textarea("descripcion",null, array_merge(['class' => 'form-control']))); ?>

                           </div>
                           <div class="form-group">
                              <?php echo e(Form::hidden("id",$user->id, array_merge(['class' => 'form-control']))); ?>

                           </div>
                           <?php echo e(Form::submit("Registrar", ['class' => 'btn btn-primary col-xs-12'])); ?>

                       <?php echo Form::close(); ?>

                   </div>
              </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger col-xs-12" data-dismiss="modal"> Close</button>

                </div>
            </div><!-- /.modal-content -->
            </div><!-- /.modal -->


          </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>