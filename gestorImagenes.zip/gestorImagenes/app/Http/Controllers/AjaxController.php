<?php

namespace GestorImagenes\Http\Controllers;

use Illuminate\Http\Request;

use GestorImagenes\Http\Requests;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\DB;

use GestorImagenes\Album;

use GestorImagenes\foto;

class AjaxController extends Controller
{
    public function test(Request $request)
    {
      if ($request->isMethod('post')){
            return response()->json(['response' => 'This is post method']);
        }

        return response()->json(['response' => 'This is get method']);
    }
}
