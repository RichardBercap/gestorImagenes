<?php

namespace GestorImagenes\Http\Controllers;

use Illuminate\Http\Request;

use GestorImagenes\Http\Requests;

use GestorImagenes\foto;

use Illuminate\Support\Facades\Storage;

class FotoController extends Controller
{
  public function __construct()
  {
      $this->middleware('auth');
      $this->middleware('auth');
  }
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
      //
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
      //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
      $this->validate($request,[
          'nombre'=>'required',
          'ruta'=>'required',
      ]);
      $foto=new foto();
      $foto->nombre    =$request->nombre;
      //obtenemos el campo file definido en el formulario
      $file = $request->file('ruta');
       //obtenemos el nombre del archivo
      $foto->ruta = rand().$file->getClientOriginalName();
      $foto->album_id  =$request->id_album;

           //indicamos que queremos guardar un nuevo archivo en el disco local
           \Storage::disk('Fotos')->put($foto->ruta,  \File::get($file));
           $foto->save();
           return redirect('admin');
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show($id)
  {
      //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit($id)
  {
      //
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
      //
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    $foto=foto::find($id);
    $ruta='Fotos/'.$foto->ruta;
     \Storage::disk('Fotos')->delete($foto->ruta);
    //Storage::delete($ruta);

    $foto->delete();
    return redirect('admin/');
  }
}
