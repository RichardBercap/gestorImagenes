<?php

namespace GestorImagenes\Http\Controllers;

use Illuminate\Http\Request;

use GestorImagenes\Http\Requests;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\DB;

use GestorImagenes\Album;

use GestorImagenes\foto;
class IndexController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
      // Get the currently authenticated user...
      $user = Auth::user();
      $id=$user->id;

      $albums=Album::where('usuario_id', $id)->get();

      return view('admin')->with("user",$user)->with("albums",$albums);

    }
    public function foto($id)
    {
      $fotos=foto::where('album_id', $id)->get();
      return view('fotos')->with("fotos",$fotos)->with("id_album",$id);
      //return "Todas tus fotos de: " .$id;
    }
}
