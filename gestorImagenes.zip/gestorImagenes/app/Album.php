<?php

namespace GestorImagenes;

use Illuminate\Database\Eloquent\Model;

class Album extends Model
{
    protected $table='album';
    protected $fillable=['id','nombre','descripcion','usuario_id'];


}
