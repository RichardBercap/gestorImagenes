<?php

namespace GestorImagenes;

use Illuminate\Database\Eloquent\Model;

class foto extends Model
{
    protected $table='fotos';
    protected $fillable=['id','nombre','ruta','album_id'];


}
