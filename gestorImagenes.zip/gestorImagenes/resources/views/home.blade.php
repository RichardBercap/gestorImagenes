@extends('layouts.app')

@section('content')
{{-- Recuperamos datos del usuario --}}
<?php $user = Auth::user() ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">{{$user->name}}</div>

                <div class="panel-body">

                  {{-- creamos un archivo message y un array con el identificador welcome --}}
                    {{trans('messages.welcome')}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
