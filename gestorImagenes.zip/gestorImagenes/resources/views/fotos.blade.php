@extends('base')
@section('content')

{{-- creacion de variables con blade --}}
@php ($i = 1)

    @if (count($fotos) == 0)

            <h1 class="fotos-no">
              No tienes Fotos en esté Albúm <br>
              <b>
                <span class="glyphicon glyphicon-camera"></span>
              </b>


             </h1>

    @endif

    @if (count($fotos) > 0)

      @foreach($fotos as $foto)

          <div class="col-xs-3 foto">
            <h3>{!!$foto->nombre!!}</h3>
              <img src="{{ asset('Fotos')}}/{!! $foto->ruta!!}" alt="" class="img-responsive imagen" style="height: 20rem;">
              <a href="{{ url('eliminar/')}}/{!! $foto->id!!}" class="btn btn-danger btn-lg col-xs-12">Eminiar</a>
          </div>


      @endforeach

    @endif
<div class="row">
  <button type="button" class="btn btn-primary btn-lg col-xs-12" name="button"  data-toggle="modal" data-target="#myModal">
    A g r e g a r    F o t o
  </button>
</div>





<!--*********** Modal **************-->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
        &times;
        </button>
        <h4 class="modal-title" id="myModalLabel">
        Llena el formulario
        </h4>


      </div>

      <div class="modal-body">
        <div class="form">
             {{Form::open(['route' => 'fotos.store', 'method' => 'post','files' => true, 'enctype' => 'multipart/form-data'])}}
                  <input type="hidden" name="_token" value="{{ csrf_token() }}">
                 <div class="form-group">
                     {{ Form::label("Nombre:")}}
                     {{ Form::text("nombre",null, array_merge(['class' => 'form-control', 'placeholder'=>'Ingresa el nombre'])) }}
                 </div>
                 <div class="form-group">
                    {{ Form::label("Ruta de la foto:")}}
                    {{ Form::file("ruta",null, array_merge(['class' => 'form-control'])) }}
                 </div>
                 <div class="form-group">
                    {{ Form::hidden("id_album",$id_album, array_merge(['class' => 'form-control'])) }}
                 </div>
                 {{ Form::submit("Subir", ['class' => 'btn btn-primary col-xs-12']) }}
             {!! Form::close() !!}
         </div>
    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger col-xs-12" data-dismiss="modal"> Close</button>

      </div>
  </div><!-- /.modal-content -->
  </div><!-- /.modal -->

@endsection
