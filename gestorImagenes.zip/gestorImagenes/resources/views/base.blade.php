<html>
    <head>
        <title>Home - @yield('title')</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
        <link rel="stylesheet" href="{{asset('css/bootstrap-theme.css')}}">
        <link rel="stylesheet" href="{{asset('css/estilos.css')}}">

    </head>
    <body>
      <header>
        <h1 class="aling-center">Administra tus Fotos</h1>
      </header>
        <div class="container">
            @yield('content')
        </div>

    </body>
    <script type="text/javascript" src="{{asset('js/jquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.js')}}"></script>
</html>
