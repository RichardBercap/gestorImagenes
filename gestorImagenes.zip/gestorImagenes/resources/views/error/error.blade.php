@extends('base')
@section('content')

<div class="container">
  <h1 class="text-center">EROR 404, PÁGINA NO ENCONTRADA!! :=(</h1>
</div>

@endsection
