@extends('base')
@section('content')

<div class="row col-xs-100">
  <h1 class="text-center">{{$user->name}}</h1>
</div>
    <p>You are an Admin</p>
    <hr>
    <blockquote>
      <p>Con este sitio guardaras tus fotos de forma segura</p>
    </blockquote>
    <div class="panel panel-default">
      <div class="panel-header">
        <h3>Tus albunes</h3>
      </div>
        <div class="panel-body">
          @if (count($albums) == 0)
              <div class="alert alert-danger">
                  <h4>No tienes albunes crados</h4>
              </div>
          @endif
          @if (count($albums) > 0)
            @foreach($albums as $album)
              <a href="/admin/album/{!!$album->id !!}">
                <div class="col-xs-3 album id='{!!$album->id !!}'">
                  <h3>{!!$album->nombre!!}</h3>
                  <p class="text-justify">
                    {!!$album->descripcion!!}
                  </p>
                </div>
              </a>


            @endforeach
          @endif

        </div>
      </div>
      <br>
      <div class="row">
          <button type="button" name="button" class="btn col-xs-4 btn-success" data-toggle="modal" data-target="#myModal">
            <span class="glyphicon glyphicon-plus"></span>
            <p>Crear Nuevo Album</p>
          </button><br><br><br>
          <div class="row">
            @if (count($errors) > 0)
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
          </div>

          <!-- Modal -->

          <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                  &times;
                  </button>
                  <h4 class="modal-title" id="myModalLabel">
                  Llena el formulario
                  </h4>


                </div>

                <div class="modal-body">
                  <div class="form">
                       {{Form::open(['route' => 'album.store', 'method' => 'post','files' => true])}}
                           <div class="form-group">
                               {{ Form::label("Nombre del albúm:")}}
                               {{ Form::text("nombre",null, array_merge(['class' => 'form-control', 'placeholder'=>'Ingresa el nombre'])) }}
                           </div>
                           <div class="form-group">
                              {{ Form::label("Descripción:")}}
                              {{ Form::textarea("descripcion",null, array_merge(['class' => 'form-control'])) }}
                           </div>
                           <div class="form-group">
                              {{ Form::hidden("id",$user->id, array_merge(['class' => 'form-control'])) }}
                           </div>
                           {{ Form::submit("Registrar", ['class' => 'btn btn-primary col-xs-12']) }}
                       {!! Form::close() !!}
                   </div>
              </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-danger col-xs-12" data-dismiss="modal"> Close</button>

                </div>
            </div><!-- /.modal-content -->
            </div><!-- /.modal -->


          </div>
      </div>

@endsection
