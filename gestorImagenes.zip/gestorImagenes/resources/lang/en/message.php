<?php

return [

    /*

    */

    'welcome'   => 'welcome to Gestor Imagenes'


];
