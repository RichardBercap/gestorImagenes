<?php

return [

    /*

    */

    'welcome'   => 'Bienvenido al home de Gestor Imagenes',
    'throttle' => 'Demasiados intentos de acceso. Por favor intente nuevamente en :seconds segundos.',

];
